package Controller;
import Model.*;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ResourceBundle;

/**Reports page that shows the schedule of the customer selected.*/
public class ReportsController implements Initializable {


        Stage stage;
        Parent scene;





        @FXML
        public ComboBox<Customer> CustomerCmb;

        @FXML
        private TableView<Appointment> ReportsTbvw;

        @FXML
        private TableColumn<Appointment, Integer> C1;

        @FXML
        private TableColumn<Appointment, String > C2;

        @FXML
        private TableColumn<Appointment, String> C3;

        @FXML
        private TableColumn<Appointment, String > C4;

        @FXML
        private TableColumn<Appointment, LocalDateTime> C5;

        @FXML
        private TableColumn<Appointment, LocalDateTime> C6;

        @FXML
        private TableColumn<Appointment, Integer> C7;
       ;

        /**Button takes you to the appointments page.*/
        @FXML
        void OnClickAppointments(ActionEvent actionEvent) throws IOException {
                stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
                scene = FXMLLoader.load(getClass().getResource("/view/Appointments.fxml"));
                stage.setScene(new Scene(scene));
                stage.show();


        }

        /**Button that takes you to the login screen and clears the login model.*/
        @FXML
        void OnClickLogOff(ActionEvent actionEvent) throws IOException {
                Login.clearUsername();
                Login.clearNow();
                stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
                scene = FXMLLoader.load(getClass().getResource("/View/Login.fxml"));
                stage.setScene(new Scene(scene));
                stage.show();

        }


        /**Button takes you to the Customer Records page.*/
        @FXML
        void onClickCustomers(ActionEvent actionEvent) throws IOException {

                stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
                scene = FXMLLoader.load(getClass().getResource("/view/CustomerRecords.fxml"));
                stage.setScene(new Scene(scene));
                stage.show();

        }


        /**Gets the customer selected in the drop down and populates the tableview with the custoners appointments.*/
        @FXML
        void onClickSelect(ActionEvent event) throws SQLException {



            AppointmentList.clearCustAppt();
            Customer c = CustomerCmb.getValue();
            if (c!=null){
            AppointmentList.initializeCustAppt(CustomerCmb.getValue().getCustomerId());}
            ReportsTbvw.setItems(AppointmentList.getCustAppt());
            C1.setCellValueFactory(new PropertyValueFactory<>("AppointmentId"));
            C1.setText("Appointment ID");
            C2.setCellValueFactory(new PropertyValueFactory<>("Title"));
            C2.setText("Title");
            C3.setCellValueFactory(new PropertyValueFactory<>("Description"));
            C3.setText("Description");
            C4.setCellValueFactory(new PropertyValueFactory<>("Type"));
            C4.setText("Type");
            C5.setCellValueFactory(new PropertyValueFactory<>("StartDisplay"));
            C5.setText("Start");
            C6.setCellValueFactory(new PropertyValueFactory<>("EndDisplay"));
            C6.setText("End");
            C7.setCellValueFactory(new PropertyValueFactory<>("CustomerId"));
            C7.setText("Customer ID");



        }

        /**Button takes you to the Overview page.*/
        @FXML
        void onClickSomething(ActionEvent actionEvent) throws IOException {
            stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(getClass().getResource("/view/Overview.fxml"));
            stage.setScene(new Scene(scene));
            stage.show();

        }


        /**Initialize method populates the customer drop down box.*/
        @Override
        public void initialize(URL location, ResourceBundle resources) {



            CustomerList.clearCustomers();

            try {
                CustomerList.initializeCustomerList();

            } catch (SQLException throwables) {
                throwables.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            CustomerCmb.setItems(CustomerList.getAllCustomers());
            CustomerCmb.setValue(CustomerList.getAllCustomers().get(0));
            AppointmentList.clearCustAppt();
            try {
                AppointmentList.initializeCustAppt(CustomerCmb.getValue().getCustomerId());
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
            ReportsTbvw.setItems(AppointmentList.getCustAppt());
            C1.setCellValueFactory(new PropertyValueFactory<>("AppointmentId"));
            C1.setText("Appointment ID");
            C2.setCellValueFactory(new PropertyValueFactory<>("Title"));
            C2.setText("Title");
            C3.setCellValueFactory(new PropertyValueFactory<>("Description"));
            C3.setText("Description");
            C4.setCellValueFactory(new PropertyValueFactory<>("Type"));
            C4.setText("Type");
            C5.setCellValueFactory(new PropertyValueFactory<>("StartDisplay"));
            C5.setText("Start");
            C6.setCellValueFactory(new PropertyValueFactory<>("EndDisplay"));
            C6.setText("End");
            C7.setCellValueFactory(new PropertyValueFactory<>("CustomerId"));
            C7.setText("Customer ID");


        }


    /**Button takes you to the type reports page.*/
    public void onClickType(ActionEvent actionEvent) throws IOException {
        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/TypeReport.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

  }


