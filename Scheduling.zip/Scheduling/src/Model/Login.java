package Model;

import Utils.DBConnection;
import Utils.DBQuery;
import com.mysql.cj.log.Log;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.ZoneId;

public class Login {

    private static String username;

    public static String getUsername() {
        return username;
    }

    public static void setUsername(String username) {
        Login.username = username;
    }

    public static void clearUsername(){username = null;}

    public static LocalDateTime now;

    public static LocalDateTime getNow() {return now;}

    public static void setNow(LocalDateTime localDateTime) {now = localDateTime;}

    public static void clearNow(){now = null;}

    public static Appointment getAppointment() throws SQLException {
        Appointment appointment = null;

        DBQuery.setStatement(DBConnection.getConnection());//create statement object
        Statement statement = DBQuery.getStatement();

        String selectAppointment = "SELECT * FROM appointments WHERE Start > '" + Timestamp.valueOf(now) + "' AND Start < '" + Timestamp.valueOf(now.plusMinutes(15)) + "';";
        statement.execute(selectAppointment);
        ResultSet rs = statement.getResultSet();


        while (rs.next())
        {
            Integer appointmentId = rs.getInt("Appointment_ID");
            String title = rs.getString("Title");
            String description = rs.getString("Description");
            String location = rs.getString("Location");
            String type = rs.getString("Type");
            Timestamp start = rs.getTimestamp("Start");
            Timestamp end = rs.getTimestamp("End");
            Timestamp createDate = rs.getTimestamp("Create_Date");
            String createBy = rs.getString("Created_By");
            Timestamp update = rs.getTimestamp("Last_Update");
            String updateBy = rs.getString("Last_Updated_By");
            Integer customerId = rs.getInt("Customer_ID");
            Integer userId = rs.getInt("User_ID");
            Integer contactID = rs.getInt("Contact_ID");
            appointment = new Appointment(appointmentId,title,description,location,type,start.toLocalDateTime(),end.toLocalDateTime(),createDate.toLocalDateTime(),createBy,update.toLocalDateTime(),updateBy,customerId,userId,contactID);
        }

        return appointment;
    }


}
