package Model;

import Utils.DBConnection;
import Utils.DBQuery;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.io.IOException;
import java.sql.*;
/**Method sets the Customers lists and lets you find the customer name.*/
public class CustomerList {

    /**Creates a list of AllCustomers.*/
    private static ObservableList<Customer> AllCustomers = FXCollections.observableArrayList();

    /**Adds a customer to the AllCustomer list.*/
    public static void addCustomer(Customer customer)
    {
        AllCustomers.add(customer);
    }

    /**returns the AllCustomer List.*/
    public static ObservableList<Customer> getAllCustomers()
    {
        return AllCustomers;
    }

    /**Uses SQL to populate the allCustomer list.*/
    public static void initializeCustomerList()  throws SQLException, IOException
    {
        //Connection conn = DBConnection.openConnection(); //Connect to database
        DBQuery.setStatement(DBConnection.getConnection());//create statement object
        Statement statement = DBQuery.getStatement();

        String selectCustomer = "SELECT * from customers";
        statement.execute(selectCustomer);
        ResultSet rs = statement.getResultSet();


        while (rs.next())
        {
            Integer customerId = rs.getInt("Customer_ID");
            String customerName = rs.getString("Customer_Name");
            String customerAddress = rs.getString("Address");
            String postalCode = rs.getString("Postal_Code");
            String phone = rs.getString("Phone");
            Timestamp createDate = rs.getTimestamp("Create_Date");
            String createBy = rs.getString("Created_By");
            Timestamp update = rs.getTimestamp("Last_Update");
            String updateBy = rs.getString("Last_Updated_By");
            Integer divisionId = rs.getInt("Division_ID");
            Customer customer = new Customer(customerId,customerName,customerAddress,postalCode,phone,createDate.toLocalDateTime(),createBy,update.toLocalDateTime(),updateBy,divisionId);
            CustomerList.addCustomer(customer);
        }
    }

    /**Clears the AllCustomer List.*/
    public static void clearCustomers(){
        AllCustomers.clear();
    }

    /**Finds the customer from a customer ID.*/
    public static Customer getCustomerId(int id) throws SQLException {
        Customer customer = null;

        DBQuery.setStatement(DBConnection.getConnection());//create statement object
        Statement statement = DBQuery.getStatement();

        String selectCustomer = "SELECT * from customers WHERE Customer_ID = " + id;
        statement.execute(selectCustomer);
        ResultSet rs = statement.getResultSet();


        while (rs.next())
        {
            Integer customerId = rs.getInt("Customer_ID");
            String customerName = rs.getString("Customer_Name");
            String customerAddress = rs.getString("Address");
            String postalCode = rs.getString("Postal_Code");
            String phone = rs.getString("Phone");
            Timestamp createDate = rs.getTimestamp("Create_Date");
            String createBy = rs.getString("Created_By");
            Timestamp update = rs.getTimestamp("Last_Update");
            String updateBy = rs.getString("Last_Updated_By");
            Integer divisionId = rs.getInt("Division_ID");
            customer = new Customer(customerId,customerName,customerAddress,postalCode,phone,createDate.toLocalDateTime(),createBy,update.toLocalDateTime(),updateBy,divisionId);

        }

        return customer;
    }

}
