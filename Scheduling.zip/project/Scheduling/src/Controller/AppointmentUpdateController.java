package Controller;

import Model.*;
import Utils.DBConnection;
import Utils.DBQuery;
import com.sun.source.tree.EmptyStatementTree;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import javax.swing.text.DateFormatter;
import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.*;
import java.time.chrono.ChronoZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;
import java.util.ResourceBundle;

import static java.sql.Timestamp.*;
import static java.time.ZoneId.systemDefault;
import static java.time.ZoneOffset.UTC;

public class AppointmentUpdateController  implements Initializable {



    Stage stage;
    Parent scene;


    @FXML
    private TextField ApptIDTxt;

    @FXML
    private TextField TitleTxt;

    @FXML
    private TextField DescTxt;

    @FXML
    private TextField LocationTxt;

    @FXML
    private ComboBox<String> TypeCmb;


    @FXML
    private DatePicker StartDate;

    @FXML
    private DatePicker EndDate;

    @FXML
    private ComboBox<LocalTime> StartTime;

    @FXML
    private ComboBox<LocalTime> EndTime;

    @FXML
    private ComboBox<Customer> CustIdCmb;

    @FXML
    private ComboBox<User> UserIdCmb;

    @FXML
    private ComboBox<Contacts> ContactCmb;

    /**Method that receives the appointment information being updated and populates the page.*/
    public void sendAppointment(Appointment appointment) throws SQLException {

        int userId = appointment.getUserId();
        User user = UserList.getUserId(userId);
        int custId = appointment.getCustomerId();
        Customer customer = CustomerList.getCustomerId(custId);
        int contactId = appointment.getContactId();
        Contacts contacts = ContactsList.getContactId(contactId);
        ZonedDateTime startDateTime = ZonedDateTime.of(appointment.getStart(), ZoneId.of("America/New_York"));
        ZonedDateTime endDateTime = ZonedDateTime.of(appointment.getEnd(), ZoneId.of("America/New_York"));
        //ZonedDateTime startDateTime = appointment.getStart();
        //ZonedDateTime endDateTime = appointment.getEnd();
        LocalDate startDate = LocalDate.from(startDateTime);
        LocalDate endDate = LocalDate.from(endDateTime);
        LocalTime startTime = LocalTime.from(appointment.getStart());
        LocalTime endTime = LocalTime.from(appointment.getEnd());
        ApptIDTxt.setText(String.valueOf(appointment.getAppointmentId()));
        TitleTxt.setText(appointment.getTitle());
        DescTxt.setText(appointment.getDescription());
        LocationTxt.setText(appointment.getLocation());
        TypeCmb.setValue(appointment.getType());
        StartDate.setValue(startDate);
        EndDate.setValue(endDate);
        StartTime.setValue(startTime);
        EndTime.setValue(endTime);
        CustIdCmb.setValue(customer);
        UserIdCmb.setValue(user);
        ContactCmb.setValue(contacts);


    }

    /**Method that saves the appointment.*/
    public void OnClickSave(ActionEvent actionEvent) throws IOException, SQLException {

        int appointmentId = Integer.parseInt(ApptIDTxt.getText());
        int customer = CustIdCmb.getSelectionModel().getSelectedItem().getCustomerId();
        int user = UserIdCmb.getSelectionModel().getSelectedItem().getUserId();
        int contact = ContactCmb.getSelectionModel().getSelectedItem().getContact_ID();
        String title = TitleTxt.getText();
        String description = DescTxt.getText();
        String location = LocationTxt.getText();
        String type = TypeCmb.getValue();
        ZonedDateTime startDateTime = ZonedDateTime.of(StartDate.getValue(), StartTime.getValue(), ZoneId.of("America/New_York"));
        ZonedDateTime endDateTime = ZonedDateTime.of(EndDate.getValue(), EndTime.getValue(), ZoneId.of("America/New_York"));
        LocalDateTime startDT = startDateTime.toLocalDateTime();
        LocalDateTime endDT = endDateTime.toLocalDateTime();

        /**Verifies the start time is before the end time.*/
        boolean time = true;
        if (startDateTime.isAfter(endDateTime)){
            time = false;
        }

        AppointmentList.clearCustAppt();
        AppointmentList.initializeCustAppt(customer);
        System.out.println("CustAppt Count: " + AppointmentList.getCustAppt().size());
        Appointment a = AppointmentList.getAppointmentId(appointmentId);
        /**Removes current appointment from CustomerAppt list.*/
        ObservableList<Appointment> CustomerAppt = AppointmentList.getCustAppt();
        for(int i=0;i<CustomerAppt.size();i++){
            if (CustomerAppt.get(i).getAppointmentId() == appointmentId)
                CustomerAppt.remove(i);
        }
        //CustomerAppt.remove(a);
        System.out.println("CustAppt Count: " + CustomerAppt.size());
        int count = 0;
        boolean start = false;
        boolean end = false;
        boolean both = false;

        /**Ensures the new appointment times do not collide with existing appointments.*/
        while (CustomerAppt.size()>count){
            LocalDateTime localStart = CustomerAppt.get(count).getStart();
            LocalDateTime localEnd = CustomerAppt.get(count).getEnd();
            ZonedDateTime zoneStart = localStart.atZone(ZoneId.of("America/New_York"));
            ZonedDateTime zoneEnd = localEnd.atZone(ZoneId.of("America/New_York"));

            System.out.println("StartDateTime: " + startDateTime + " /zoneStart: " + zoneStart);
            System.out.println("EndDateTime: " + endDateTime + "zoneEnd: " + zoneEnd);
            if ((startDateTime.isAfter(zoneStart) || startDateTime.isEqual(zoneStart)) && (startDateTime.isBefore(zoneEnd)))
            {


                start = true;


            }
            count++;

        }
        count = 0;
        while (CustomerAppt.size()>count){
            LocalDateTime localStart = CustomerAppt.get(count).getStart();
            LocalDateTime localEnd = CustomerAppt.get(count).getEnd();
            ZonedDateTime zoneStart = localStart.atZone(ZoneId.of("America/New_York"));
            ZonedDateTime zoneEnd = localEnd.atZone(ZoneId.of("America/New_York"));

            if((endDateTime.isAfter(zoneStart)) && (endDateTime.isBefore(zoneEnd) || endDateTime.isEqual(zoneEnd)))
            {
                end = true;

            }
            count++;
        }
        count = 0;
        while (CustomerAppt.size()>count){
            LocalDateTime localStart = CustomerAppt.get(count).getStart();
            LocalDateTime localEnd = CustomerAppt.get(count).getEnd();
            ZonedDateTime zoneStart = localStart.atZone(ZoneId.of("America/New_York"));
            ZonedDateTime zoneEnd = localEnd.atZone(ZoneId.of("America/New_York"));

            if ((startDateTime.isBefore(zoneStart) || startDateTime.isEqual(zoneStart)) && (endDateTime.isAfter(zoneEnd) || endDateTime.isEqual(zoneEnd))){
                both = true;
            }
            count++;
        }



        System.out.println("Start: " + start);

        System.out.println("End: " + end);
        System.out.println("Both: " + both);


        /**If the appointment does not collide and start is before end the appointment is updated.*/
        if ((!start) && (!end) && (!both) && (time) ){
        String updateStatement = "UPDATE appointments SET Title = ?, Description = ?, Location = ?, Type = ?, Start = ?, End = ?, Last_Update = ?, Last_Updated_By = ?, Customer_ID = ?, User_ID = ?, Contact_ID = ? WHERE Appointment_ID = ?";
        //DBQuery.setPreparedStatement(DBConnection.getConnection());
        //PreparedStatement ps = DBQuery.getPreparedStatement();
        PreparedStatement ps = DBConnection.getConnection().prepareStatement(updateStatement);

        //key value mapping
        ps.setString(1,title);
        ps.setString(2,description);
        ps.setString(3,location);
        ps.setString(4,type);
        ps.setTimestamp(5,Timestamp.valueOf(startDT));
        ps.setTimestamp(6,Timestamp.valueOf(endDT));
        ps.setTimestamp(7, valueOf(LocalDateTime.now()));
        ps.setString(8,Login.getUsername());
        ps.setInt(9,customer);
        ps.setInt(10,user);
        ps.setInt(11,contact);
        ps.setInt(12,appointmentId);

        ps.execute();//execute prepared statement

        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/Appointments.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();}

        /**Error message when start time is after the end time.*/
        else if((!start) && (!end) && (!both) && (!time) ) {
            Alert alert = new Alert(Alert.AlertType.ERROR, "Start Date and Time must be before the End Date and Time.");
            Optional<ButtonType> result = alert.showAndWait();
        }
        /**Error message when the Customer Appointments collide.*/
        else  {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Appointment Conflicts");
            alert.setContentText("This Customer has another appointment at this time.");
            alert.showAndWait();
        }
    }

    /**Cancelled the appointment update and returns to the appointemnts screen.*/
    public void OnClickCancel(ActionEvent actionEvent) throws IOException {
        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/Appointments.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**Populates the drop downs with the proper information.*/
    @Override
    public void initialize(URL location, ResourceBundle resources) {

        ZonedDateTime test = ZonedDateTime.of(LocalDate.now(),LocalTime.of(8,0),ZoneId.of("America/New_York"));
        ZonedDateTime test2 = ZonedDateTime.of(LocalDate.now(),LocalTime.of(22,0),ZoneId.of("America/New_York"));
        ZonedDateTime localStart = test.withZoneSameInstant(ZoneId.systemDefault());
        ZonedDateTime localEnd = test2.withZoneSameInstant(ZoneId.systemDefault());
        LocalTime start = localStart.toLocalTime();
        LocalTime end = localEnd.toLocalTime();

        while(start.isBefore(end.plusSeconds(1))){
            StartTime.getItems().add(start);
            EndTime.getItems().add(start);
            start = start.plusMinutes(15);
        }

        CustomerList.clearCustomers();
        try {
            CustomerList.initializeCustomerList();

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        UserList.clearUsers();
        try{UserList.initializeUserList();} catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        ContactsList.clearContact();
        try{ContactsList.initializeContactList();} catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        ObservableList<String> types = FXCollections.observableArrayList("Interview", "Planning Session", "Job Summary", "De-Briefing");

        TypeCmb.setItems(types);
        CustIdCmb.setItems(CustomerList.getAllCustomers());
        UserIdCmb.setItems(UserList.getAllUsers());
        ContactCmb.setItems(ContactsList.getAllContacts());

    }
}
