package Model;
/**My second Lambda interface using a get string.*/
public interface DeletableInterface {
    String getMessage(String s);
}
