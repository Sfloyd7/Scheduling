package Controller;

import Model.*;
import Utils.DBConnection;
import Utils.DBQuery;
import com.sun.source.tree.EmptyStatementTree;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import javax.swing.text.DateFormatter;
import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.Optional;
import java.util.ResourceBundle;

import static java.sql.Timestamp.*;
import static java.time.ZoneOffset.UTC;

public class AppointmentUpdateController  implements Initializable {



    Stage stage;
    Parent scene;


    @FXML
    private TextField ApptIDTxt;

    @FXML
    private TextField TitleTxt;

    @FXML
    private TextField DescTxt;

    @FXML
    private TextField LocationTxt;

    @FXML
    private TextField TypeTxt;


    @FXML
    private DatePicker StartDate;

    @FXML
    private DatePicker EndDate;

    @FXML
    private ComboBox<LocalTime> StartTime;

    @FXML
    private ComboBox<LocalTime> EndTime;

    @FXML
    private ComboBox<Customer> CustIdCmb;

    @FXML
    private ComboBox<User> UserIdCmb;

    @FXML
    private ComboBox<Contacts> ContactCmb;

    public void sendAppointment(Appointment appointment) throws SQLException {

        int userId = appointment.getUserId();
        User user = UserList.getUserId(userId);
        int custId = appointment.getCustomerId();
        Customer customer = CustomerList.getCustomerId(custId);
        int contactId = appointment.getContactId();
        Contacts contacts = ContactsList.getContactId(contactId);
        LocalDate startDate = LocalDate.from(appointment.getStart());
        LocalDate endDate = LocalDate.from(appointment.getEnd());
        LocalTime startTime = LocalTime.from(appointment.getStart());
        LocalTime endTime = LocalTime.from(appointment.getEnd());
        ApptIDTxt.setText(String.valueOf(appointment.getAppointmentId()));
        TitleTxt.setText(appointment.getTitle());
        DescTxt.setText(appointment.getDescription());
        LocationTxt.setText(appointment.getLocation());
        TypeTxt.setText(appointment.getType());
        StartDate.setValue(startDate);
        EndDate.setValue(endDate);
        StartTime.setValue(startTime);
        EndTime.setValue(endTime);
        CustIdCmb.setValue(customer);
        UserIdCmb.setValue(user);
        ContactCmb.setValue(contacts);


    }

    public void OnClickSave(ActionEvent actionEvent) throws IOException, SQLException {

        int appointmentId = Integer.parseInt(ApptIDTxt.getText());
        int customer = CustIdCmb.getSelectionModel().getSelectedItem().getCustomerId();
        int user = UserIdCmb.getSelectionModel().getSelectedItem().getUserId();
        int contact = ContactCmb.getSelectionModel().getSelectedItem().getContact_ID();
        String title = TitleTxt.getText();
        String description = DescTxt.getText();
        String location = LocationTxt.getText();
        String type = TypeTxt.getText();
        ZonedDateTime startDateTime = ZonedDateTime.of(StartDate.getValue(), StartTime.getValue(), ZoneId.of("America/New_York"));
        ZonedDateTime endDateTime = ZonedDateTime.of(EndDate.getValue(), EndTime.getValue(), ZoneId.of("America/New_York"));
        LocalDateTime startDT = startDateTime.toLocalDateTime();
        LocalDateTime endDT = endDateTime.toLocalDateTime();

        if (startDateTime.isAfter(endDateTime)){
            Alert alert = new Alert(Alert.AlertType.ERROR, "Start Date and Time must be before the End Date and Time.");
            Optional<ButtonType> result = alert.showAndWait();
        }
        Appointment appointment = new Appointment(appointmentId,title,description,location,type,startDT,endDT,null,null,LocalDateTime.now(),Login.getUsername(),customer,user,contact);

        AppointmentList.clearCustAppt();
        AppointmentList.initializeCustAppt(customer);
        AppointmentList.deleteCustAppt(appointment);

        String updateStatement = "UPDATE appointments SET Title = ?, Description = ?, Location = ?, Type = ?, Start = ?, End = ?, Last_Update = ?, Last_Updated_By = ?, Customer_ID = ?, User_ID = ?, Contact_ID = ? WHERE Appointment_ID = ?";
        //DBQuery.setPreparedStatement(DBConnection.getConnection());
        //PreparedStatement ps = DBQuery.getPreparedStatement();
        PreparedStatement ps = DBConnection.getConnection().prepareStatement(updateStatement);

        //key value mapping
        ps.setString(1,title);
        ps.setString(2,description);
        ps.setString(3,location);
        ps.setString(4,type);
        ps.setTimestamp(5,Timestamp.valueOf(startDT));
        ps.setTimestamp(6,Timestamp.valueOf(endDT));
        ps.setTimestamp(7, valueOf(LocalDateTime.now()));
        ps.setString(8,Login.getUsername());
        ps.setInt(9,customer);
        ps.setInt(10,user);
        ps.setInt(11,contact);
        ps.setInt(12,appointmentId);

        ps.execute();//execute prepared statement

        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/Appointments.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    public void OnClickCancel(ActionEvent actionEvent) throws IOException {
        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/Appointments.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        ZonedDateTime test = ZonedDateTime.of(LocalDate.now(),LocalTime.of(8,0),ZoneId.of("America/New_York"));
        ZonedDateTime test2 = ZonedDateTime.of(LocalDate.now(),LocalTime.of(22,0),ZoneId.of("America/New_York"));
        ZonedDateTime localStart = test.withZoneSameInstant(ZoneId.systemDefault());
        ZonedDateTime localEnd = test2.withZoneSameInstant(ZoneId.systemDefault());
        LocalTime start = localStart.toLocalTime();
        LocalTime end = localEnd.toLocalTime();

        while(start.isBefore(end.plusSeconds(1))){
            StartTime.getItems().add(start);
            EndTime.getItems().add(start);
            start = start.plusMinutes(15);
        }

        CustomerList.clearCustomers();
        try {
            CustomerList.initializeCustomerList();

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        UserList.clearUsers();
        try{UserList.initializeUserList();} catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        ContactsList.clearContact();
        try{ContactsList.initializeContactList();} catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        CustIdCmb.setItems(CustomerList.getAllCustomers());
        UserIdCmb.setItems(UserList.getAllUsers());
        ContactCmb.setItems(ContactsList.getAllContacts());

    }
}
