package Utils;

import java.time.*;
import java.util.TimeZone;

public class TimeConversion {



    /*LocalDate parisDate = LocalDate.of(2021, 9,29);
    LocalTime parisTime = LocalTime.of(8,00);
    ZoneId parisZoneId = ZoneId.of("Europe/Paris");
    ZonedDateTime parisZDT = ZonedDateTime.of(parisDate,parisTime, parisZoneId);

    ZoneId localZoneId = ZoneId.of(TimeZone.getDefault().getID());

    Instant parisToGMTInstant = parisZDT.toInstant();
    ZonedDateTime parisToLocalZDT = parisZDT.withZoneSameInstant(localZoneId);
    ZonedDateTime gmtToLocalZDT = parisToGMTInstant.atZone(localZoneId);*/

    public static Instant getUTC (ZonedDateTime time){
        Instant utcTime = time.toInstant();
        return utcTime;
    }



}
