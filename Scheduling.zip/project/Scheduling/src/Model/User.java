package Model;

import java.time.LocalDateTime;
/**Method for the User with Getters and Setters.*/
public class User {
    private int UserId;
    private String UserName;
    private String Password;
    private LocalDateTime CreateDate;
    private String CreateBy;
    private LocalDateTime LastUpdate;
    private String UpdateBy;

    /**Constructor for the User.*/
    public User(int userId, String userName, String password, LocalDateTime createDate, String createBy, LocalDateTime lastUpdate, String updateBy) {
        UserId = userId;
        UserName = userName;
        Password = password;
        CreateDate = createDate;
        CreateBy = createBy;
        LastUpdate = lastUpdate;
        UpdateBy = updateBy;
    }

    /**@return Returns UserId.*/
    public int getUserId() {
        return UserId;
    }

    /**@param userId Sets the user ID.*/
    public void setUserId(int userId) {
        UserId = userId;
    }

    /**@return Returns the Username.*/
    public String getUserName() {
        return UserName;
    }

    /**@param userName Sets the username for a user.*/
    public void setUserName(String userName) {
        UserName = userName;
    }

    /**@return Returns the User's password.*/
    public String getPassword() {
        return Password;
    }

    /**@param password Sets the user's password.*/
    public void setPassword(String password) {
        Password = password;
    }

    /**@return Returns the timestamp when the user was created.*/
    public LocalDateTime getCreateDate() {
        return CreateDate;
    }

    /**@param  createDate Sets the Timestamp when the user was created.*/
    public void setCreateDate(LocalDateTime createDate) {
        CreateDate = createDate;
    }

    /**@return Returns who created the user.*/
    public String getCreateBy() {
        return CreateBy;
    }

    /**@param createBy Sets who created the User.*/
    public void setCreateBy(String createBy) {
        CreateBy = createBy;
    }

    /**@return Returns the last date and time the user was updated.*/
    public LocalDateTime getLastUpdate() {
        return LastUpdate;
    }

    /**@param lastUpdate sets the date and time for when the user was updated.*/
    public void setLastUpdate(LocalDateTime lastUpdate) {
        LastUpdate = lastUpdate;
    }

    /**@return Returns who last updated the User.*/
    public String getUpdateBy() {
        return UpdateBy;
    }

    /**@param updateBy Sets who last updated the user.*/
    public void setUpdateBy(String updateBy) {
        UpdateBy = updateBy;
    }

    /**overrides the to string to show the username on the drop downs.*/
    @Override
    public String toString(){
        return (UserName);
    }
}
