package Controller;

import Model.*;
import Utils.DBConnection;
import Utils.DBQuery;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.EventObject;
import java.util.Optional;
import java.util.ResourceBundle;

public class AppointmentDetailsController implements Initializable {


    Stage stage;
    Parent scene;

    @FXML
    private TextField ApptIDTxt;

    @FXML
    private TextField TitleTxt;

    @FXML
    private TextField DescTxt;

    @FXML
    private TextField LocationTxt;

    @FXML
    private TextField TypeTxt;

    @FXML
    private DatePicker StartDate;

    @FXML
    private DatePicker EndDate;

    @FXML
    private ComboBox<LocalTime> StartTime;

    @FXML
    private ComboBox<LocalTime> EndTime;

    @FXML
    private ComboBox<Contacts> contactCmb;

    @FXML
    private ComboBox<Customer> CustomerCmb;

    @FXML
    private ComboBox<User> UserIdCmb;



    public void OnClickSave(ActionEvent actionEvent) throws IOException, SQLException {

        int customer = CustomerCmb.getSelectionModel().getSelectedItem().getCustomerId();
        int user = UserIdCmb.getSelectionModel().getSelectedItem().getUserId();
        int contact = contactCmb.getSelectionModel().getSelectedItem().getContact_ID();
        String title = TitleTxt.getText();
        String description = DescTxt.getText();
        String location = LocationTxt.getText();
        String type = TypeTxt.getText();
        ZonedDateTime startDateTime = ZonedDateTime.of(StartDate.getValue(), StartTime.getValue(), ZoneId.of("America/New_York"));
        ZonedDateTime endDateTime = ZonedDateTime.of(EndDate.getValue(), EndTime.getValue(), ZoneId.of("America/New_York"));
        LocalDateTime startDT = startDateTime.toLocalDateTime();
        LocalDateTime endDT = endDateTime.toLocalDateTime();


        if (startDateTime.isAfter(endDateTime)){
            Alert alert = new Alert(Alert.AlertType.ERROR, "Start Date and Time must be before the End Date and Time.");
            Optional<ButtonType> result = alert.showAndWait();
        }

        AppointmentList.clearCustAppt();
        AppointmentList.initializeCustAppt(customer);

        AppointmentList.getCustAppt();



        //Connection conn = DBConnection.openConnection(); //Connect to database
        String insertStatement = "INSERT INTO appointments (Title, Description, Location, Type, Start, End, Create_Date, Created_By, Last_Update,Last_Updated_By, Customer_ID, User_ID, Contact_ID) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)";
        //DBQuery.setPreparedStatement(DBConnection.getConnection(), insertStatement);
        //PreparedStatement ps = DBQuery.getPreparedStatement();
        PreparedStatement ps = DBConnection.getConnection().prepareStatement(insertStatement);

        //key value mapping
        ps.setString(1, title);
        ps.setString(2, description);
        ps.setString(3, location);
        ps.setString(4, type);
        ps.setTimestamp(5, Timestamp.valueOf(startDT));
        ps.setTimestamp(6, Timestamp.valueOf(endDT));
        ps.setTimestamp(7, Timestamp.valueOf(LocalDateTime.now()));
        ps.setString(8, Login.getUsername());
        ps.setTimestamp(9, Timestamp.valueOf(LocalDateTime.now()));
        ps.setString(10, Login.getUsername());
        ps.setInt(11,customer);
        ps.setInt(12,user);
        ps.setInt(13,contact);


        ps.execute();//execute prepared statement

        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/Appointments.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    public void OnClickCancel(ActionEvent actionEvent) throws IOException {
        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/Appointments.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();


    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        ZonedDateTime test = ZonedDateTime.of(LocalDate.now(),LocalTime.of(8,0),ZoneId.of("America/New_York"));
        ZonedDateTime test2 = ZonedDateTime.of(LocalDate.now(),LocalTime.of(22,0),ZoneId.of("America/New_York"));
        ZonedDateTime localStart = test.withZoneSameInstant(ZoneId.systemDefault());
        ZonedDateTime localEnd = test2.withZoneSameInstant(ZoneId.systemDefault());
        LocalTime start = localStart.toLocalTime();
        LocalTime end = localEnd.toLocalTime();

        while (start.isBefore(end.plusSeconds(1))) {
            StartTime.getItems().add(start);
            EndTime.getItems().add(start);
            start = start.plusMinutes(15);
        }

        StartTime.getSelectionModel().select(LocalTime.of(8, 0));

        CustomerList.clearCustomers();
        try {
            CustomerList.initializeCustomerList();

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        UserList.clearUsers();
        try{UserList.initializeUserList();} catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        ContactsList.clearContact();
        try{ContactsList.initializeContactList();} catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        CustomerCmb.setItems(CustomerList.getAllCustomers());
        UserIdCmb.setItems(UserList.getAllUsers());
        contactCmb.setItems(ContactsList.getAllContacts());
    }
}