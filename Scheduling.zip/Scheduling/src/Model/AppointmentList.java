package Model;

import Utils.DBConnection;
import Utils.DBQuery;
import com.mysql.cj.log.Log;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.io.IOException;
import java.sql.*;
import java.time.LocalDateTime;

public class AppointmentList {

    private static ObservableList<Appointment> AllAppointments = FXCollections.observableArrayList();

    private static ObservableList<Appointment> CustAppt = FXCollections.observableArrayList();

    public static void addCustAppt(Appointment appointment) {CustAppt.add(appointment);}

    public static void clearCustAppt() {CustAppt.clear();}

    public static void deleteCustAppt(Appointment appointment){CustAppt.remove(appointment);}

    public static void initializeCustAppt (int CustomerId) throws SQLException {
        DBQuery.setStatement(DBConnection.getConnection());
        Statement statement = DBQuery.getStatement();

        String selectCustomerID = ("SELECT * from appointments WHERE Customer_ID = " + CustomerId);
        statement.execute(selectCustomerID);
        ResultSet rs = statement.getResultSet();

        while (rs.next()){
            Integer appointmentId = rs.getInt("Appointment_ID");
            String title = rs.getString("Title");
            String description = rs.getString("Description");
            String location = rs.getString("Location");
            String type = rs.getString("Type");
            Timestamp start = rs.getTimestamp("Start");
            Timestamp end = rs.getTimestamp("End");
            Timestamp createDate = rs.getTimestamp("Create_Date");
            String createBy = rs.getString("Created_By");
            Timestamp update = rs.getTimestamp("Last_Update");
            String updateBy = rs.getString("Last_Updated_By");
            Integer customerId = rs.getInt("Customer_ID");
            Integer userId = rs.getInt("User_ID");
            Integer contactID = rs.getInt("Contact_ID");
            Appointment appointment = new Appointment(appointmentId,title,description,location,type,start.toLocalDateTime(),end.toLocalDateTime(),createDate.toLocalDateTime(),createBy,update.toLocalDateTime(),updateBy,customerId,userId,contactID);
            AppointmentList.addCustAppt(appointment);
        }
    }

    public static ObservableList<Appointment> getCustAppt() {return CustAppt;}

    public static void addAppointment(Appointment appointment)
    {
        AllAppointments.add(appointment);
    }


    public static ObservableList<Appointment> getAllAppointments()
    {
        return AllAppointments;
    }

    public static void deleteAppointment(int appointmentId) throws SQLException {
        DBQuery.setStatement(DBConnection.getConnection());//create statement object
        Statement statement = DBQuery.getStatement();

        String deleteAppointment = "DELETE FROM appointments WHERE Appointment_ID = " + appointmentId+ ";";
        statement.execute(deleteAppointment);
    }


    public static void initializeAppointmentList()  throws SQLException, IOException
    {
        //Connection conn = DBConnection.openConnection(); //Connect to database
        DBQuery.setStatement(DBConnection.getConnection());//create statement object
        Statement statement = DBQuery.getStatement();

        String selectAppointment = "SELECT * from appointments";
        statement.execute(selectAppointment);
        ResultSet rs = statement.getResultSet();


        while (rs.next())
        {
            Integer appointmentId = rs.getInt("Appointment_ID");
            String title = rs.getString("Title");
            String description = rs.getString("Description");
            String location = rs.getString("Location");
            String type = rs.getString("Type");
            Timestamp start = rs.getTimestamp("Start");
            Timestamp end = rs.getTimestamp("End");
            Timestamp createDate = rs.getTimestamp("Create_Date");
            String createBy = rs.getString("Created_By");
            Timestamp update = rs.getTimestamp("Last_Update");
            String updateBy = rs.getString("Last_Updated_By");
            Integer customerId = rs.getInt("Customer_ID");
            Integer userId = rs.getInt("User_ID");
            Integer contactID = rs.getInt("Contact_ID");
            Appointment appointment = new Appointment(appointmentId,title,description,location,type,start.toLocalDateTime(),end.toLocalDateTime(),createDate.toLocalDateTime(),createBy,update.toLocalDateTime(),updateBy,customerId,userId,contactID);
            AppointmentList.addAppointment(appointment);
        }
    }

    public static void clearAppointments(){
        AllAppointments.clear();
    }

    private static ObservableList<Appointment> weekAppts = FXCollections.observableArrayList();

    public static void clearWeekAppts() {weekAppts.clear();}

    public static void addWeekAppointment(Appointment appointment)
    {
        weekAppts.add(appointment);
    }

    public static ObservableList<Appointment> getWeekAppts()
    {
        return weekAppts;
    }

    public static void initializeWeekAppointmentList()  throws SQLException, IOException
    {
        //Connection conn = DBConnection.openConnection(); //Connect to database
        DBQuery.setStatement(DBConnection.getConnection());//create statement object
        Statement statement = DBQuery.getStatement();

        String selectAppointment = "SELECT * FROM appointments WHERE Start > '" + Timestamp.valueOf(Login.now) + "' AND Start < '" + Timestamp.valueOf(Login.now.plusDays(7)) + "';";
        statement.execute(selectAppointment);
        ResultSet rs = statement.getResultSet();


        while (rs.next())
        {
            Integer appointmentId = rs.getInt("Appointment_ID");
            String title = rs.getString("Title");
            String description = rs.getString("Description");
            String location = rs.getString("Location");
            String type = rs.getString("Type");
            Timestamp start = rs.getTimestamp("Start");
            Timestamp end = rs.getTimestamp("End");
            Timestamp createDate = rs.getTimestamp("Create_Date");
            String createBy = rs.getString("Created_By");
            Timestamp update = rs.getTimestamp("Last_Update");
            String updateBy = rs.getString("Last_Updated_By");
            Integer customerId = rs.getInt("Customer_ID");
            Integer userId = rs.getInt("User_ID");
            Integer contactID = rs.getInt("Contact_ID");
            Appointment appointment = new Appointment(appointmentId,title,description,location,type,start.toLocalDateTime(),end.toLocalDateTime(),createDate.toLocalDateTime(),createBy,update.toLocalDateTime(),updateBy,customerId,userId,contactID);
            AppointmentList.addWeekAppointment(appointment);
        }
    }

    private static ObservableList<Appointment> monthAppts = FXCollections.observableArrayList();

    public static void clearMonthAppts() {weekAppts.clear();}

    public static void addMonthAppointment(Appointment appointment)
    {
        monthAppts.add(appointment);
    }

    public static ObservableList<Appointment> getMonthAppts()
    {
        return monthAppts;
    }

    public static void initializeMonthAppointmentList()  throws SQLException, IOException
    {
        //Connection conn = DBConnection.openConnection(); //Connect to database
        DBQuery.setStatement(DBConnection.getConnection());//create statement object
        Statement statement = DBQuery.getStatement();

        String selectAppointment = "SELECT * FROM appointments WHERE Start > '" + Timestamp.valueOf(Login.now) + "' AND Start < '" + Timestamp.valueOf(Login.now.plusMonths(1)) + "';";
        statement.execute(selectAppointment);
        ResultSet rs = statement.getResultSet();


        while (rs.next())
        {
            Integer appointmentId = rs.getInt("Appointment_ID");
            String title = rs.getString("Title");
            String description = rs.getString("Description");
            String location = rs.getString("Location");
            String type = rs.getString("Type");
            Timestamp start = rs.getTimestamp("Start");
            Timestamp end = rs.getTimestamp("End");
            Timestamp createDate = rs.getTimestamp("Create_Date");
            String createBy = rs.getString("Created_By");
            Timestamp update = rs.getTimestamp("Last_Update");
            String updateBy = rs.getString("Last_Updated_By");
            Integer customerId = rs.getInt("Customer_ID");
            Integer userId = rs.getInt("User_ID");
            Integer contactID = rs.getInt("Contact_ID");
            Appointment appointment = new Appointment(appointmentId,title,description,location,type,start.toLocalDateTime(),end.toLocalDateTime(),createDate.toLocalDateTime(),createBy,update.toLocalDateTime(),updateBy,customerId,userId,contactID);
            AppointmentList.addMonthAppointment(appointment);
        }
    }


}
