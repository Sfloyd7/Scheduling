package Model;

import java.sql.Timestamp;
/**The method for the getters and setters for the countries in the database.*/
public class Countries {

    private int CountryId;
    private String Country;
    private Timestamp CreateDate;
    private String CreateBy;
    private Timestamp LastUpdated;
    private String UpdatedBy;

    /**@return Returns the country ID.*/
    public int getCountryId() {
        return CountryId;
    }

    /**@param countryId Sets the country ID for a County.*/
    public void setCountryId(int countryId) {
        CountryId = countryId;
    }

    /**@return Returns the Country Name.*/
    public String getCountry() {
        return Country;
    }

    /**@param country Sets the Country Name.*/
    public void setCountry(String country) {
        Country = country;
    }

    /**@return Returns the Timestamp for the when the country was entered in the database.*/
    public Timestamp getCreateDate() {
        return CreateDate;
    }

    /**@param createDate Sets the current timesteamp for adding a country to the database.*/
    public void setCreateDate(Timestamp createDate) {
        CreateDate = createDate;
    }

    /**@return Returns who entered the country into the Database.*/
    public String getCreateBy() {
        return CreateBy;
    }

    /**@param createBy Sets who entered the country into the database.*/
    public void setCreateBy(String createBy) {
        CreateBy = createBy;
    }

    /**@return Returns the last time the country was updated.*/
    public Timestamp getLastUpdated() {
        return LastUpdated;
    }

    /**@param lastUpdated Sets the Date and Time the country was last updated.*/
    public void setLastUpdated(Timestamp lastUpdated) {
        LastUpdated = lastUpdated;
    }

    /**@return Returns who last updated that country.*/
    public String getUpdatedBy() {
        return UpdatedBy;
    }

    /**@param updatedBy Sets who last updated the country.*/
    public void setUpdatedBy(String updatedBy) {
        UpdatedBy = updatedBy;
    }

    /**Constructor for a new country.*/
    public Countries(int countryId, String country, Timestamp createDate, String createBy, Timestamp lastUpdated, String updatedBy) {
        CountryId = countryId;
        Country = country;
        CreateDate = createDate;
        CreateBy = createBy;
        LastUpdated = lastUpdated;
        UpdatedBy = updatedBy;
    }

    /**Overrides the country to show the name of the country for the drop downs.*/
    @Override
    public String toString(){
        return (Country);
    }


}
