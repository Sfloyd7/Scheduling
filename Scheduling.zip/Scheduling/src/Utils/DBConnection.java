package Utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import static java.lang.Class.forName;

public class DBConnection {

    //JDBC URL parts
    private static final String protocol = "jdbc";
    private static final String vendorName = ":mysql:";
    private static final String IPAddress = "//wgudb.ucertify.com:3306/";
    private static final String dbname = "WJ06jgo";

    //JDBC URL
    private static final String jdbcURL = protocol + vendorName + IPAddress + dbname;

    //Driver Interface Reference
    private static final String MYSQLJDBCDriver = "com.mysql.cj.jdbc.Driver";
    private static Connection conn = null;

    private static final String Username = "U06jgo"; //username
    private static String Password = "53688784359";

    public static Connection startConnection ()
    {
        try {
            Class.forName(MYSQLJDBCDriver);
            conn = DriverManager.getConnection(jdbcURL,Username,Password);
            System.out.println("Connection Successful.");
        }
        catch(ClassNotFoundException e)
        {
            e.printStackTrace();
        }
        catch(SQLException e)
        {
            //System.out.println(e.getMessage());
            e.printStackTrace();
        }

        return conn;
    }

    public static Connection getConnection(){
        return conn;
    }


    public static void closeConnection()
    {
        try{
            conn.close();
        }
        catch (Exception e){
            //do nothing
        }
    }

}
