package Model;

import Utils.DBConnection;
import Utils.DBQuery;
import com.mysql.cj.log.Log;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.io.IOException;
import java.sql.*;
import java.time.LocalDateTime;

/**This Method makes the different observable lists for the appointments. There are several types.
 * The all appointments list. the list for appointments for specific customers.
 * there is one that returns the appointment based on the appointment ID.*/
public class AppointmentList {


    /**Creates the ovservable list for allAppointments.*/
    private static ObservableList<Appointment> AllAppointments = FXCollections.observableArrayList();

    /**Creates the observable list for the CustAppt for all appointments for a given customer.*/
    private static ObservableList<Appointment> CustAppt = FXCollections.observableArrayList();

    /**Adds appointment to the CustAppt observable list.*/
    public static void addCustAppt(Appointment appointment) {CustAppt.add(appointment);}

    /**Clears the CustAppt observable list.*/
    public static void clearCustAppt() {CustAppt.clear();}

    /**Removes an appointment from the CustAppt list.*/
    public static void deleteCustAppt(Appointment appointment){CustAppt.remove(appointment);}

    /**Returns an appointment from an Appointment ID.*/
    public static Appointment getAppointmentId(int id) throws SQLException {
        Appointment appointment = null;

        DBQuery.setStatement(DBConnection.getConnection());//create statement object
        Statement statement = DBQuery.getStatement();

        String selectCustomer = "SELECT * from appointments WHERE Appointment_ID = " + id;
        statement.execute(selectCustomer);
        ResultSet rs = statement.getResultSet();


        while (rs.next())
        {
            Integer appointmentId = rs.getInt("Appointment_ID");
            String title = rs.getString("Title");
            String description = rs.getString("Description");
            String location = rs.getString("Location");
            String type = rs.getString("Type");
            Timestamp start = rs.getTimestamp("Start");
            Timestamp end = rs.getTimestamp("End");
            Timestamp createDate = rs.getTimestamp("Create_Date");
            String createBy = rs.getString("Created_By");
            Timestamp update = rs.getTimestamp("Last_Update");
            String updateBy = rs.getString("Last_Updated_By");
            Integer customerId = rs.getInt("Customer_ID");
            Integer userId = rs.getInt("User_ID");
            Integer contactID = rs.getInt("Contact_ID");
            appointment = new Appointment(appointmentId,title,description,location,type,start.toLocalDateTime(),end.toLocalDateTime(),createDate.toLocalDateTime(),createBy,update.toLocalDateTime(),updateBy,customerId,userId,contactID);

        }

        return appointment;
    }

    /**This code does an SQL search to add all appointments to the CustAppt based on a CustomerID provided.*/
    public static void initializeCustAppt (int CustomerId) throws SQLException {
        DBQuery.setStatement(DBConnection.getConnection());
        Statement statement = DBQuery.getStatement();

        String selectCustomerID = ("SELECT * from appointments WHERE Customer_ID = " + CustomerId);
        statement.execute(selectCustomerID);
        ResultSet rs = statement.getResultSet();

        while (rs.next()){
            Integer appointmentId = rs.getInt("Appointment_ID");
            String title = rs.getString("Title");
            String description = rs.getString("Description");
            String location = rs.getString("Location");
            String type = rs.getString("Type");
            Timestamp start = rs.getTimestamp("Start");
            Timestamp end = rs.getTimestamp("End");
            Timestamp createDate = rs.getTimestamp("Create_Date");
            String createBy = rs.getString("Created_By");
            Timestamp update = rs.getTimestamp("Last_Update");
            String updateBy = rs.getString("Last_Updated_By");
            Integer customerId = rs.getInt("Customer_ID");
            Integer userId = rs.getInt("User_ID");
            Integer contactID = rs.getInt("Contact_ID");
            Appointment appointment = new Appointment(appointmentId,title,description,location,type,start.toLocalDateTime(),end.toLocalDateTime(),createDate.toLocalDateTime(),createBy,update.toLocalDateTime(),updateBy,customerId,userId,contactID);
            AppointmentList.addCustAppt(appointment);
        }
    }

    /**Returns the whole CustAppt observable list.*/
    public static ObservableList<Appointment> getCustAppt() {return CustAppt;}

    /**Adds an Appointment to the allAppointments list.*/
    public static void addAppointment(Appointment appointment)
    {
        AllAppointments.add(appointment);
    }

    /**Returns the AllAppointments list.*/
    public static ObservableList<Appointment> getAllAppointments()
    {
        return AllAppointments;
    }

    /**Deletes an appointment from the SQL database.*/
    public static void deleteAppointment(int appointmentId) throws SQLException {
        DBQuery.setStatement(DBConnection.getConnection());//create statement object
        Statement statement = DBQuery.getStatement();

        String deleteAppointment = "DELETE FROM appointments WHERE Appointment_ID = " + appointmentId+ ";";
        statement.execute(deleteAppointment);
    }

    /**Uses SQL to return all appointments in the database and adds it to the AllAppointment list.*/
    public static void initializeAppointmentList()  throws SQLException, IOException
    {
        //Connection conn = DBConnection.openConnection(); //Connect to database
        DBQuery.setStatement(DBConnection.getConnection());//create statement object
        Statement statement = DBQuery.getStatement();

        String selectAppointment = "SELECT * from appointments";
        statement.execute(selectAppointment);
        ResultSet rs = statement.getResultSet();


        while (rs.next())
        {
            Integer appointmentId = rs.getInt("Appointment_ID");
            String title = rs.getString("Title");
            String description = rs.getString("Description");
            String location = rs.getString("Location");
            String type = rs.getString("Type");
            Timestamp start = rs.getTimestamp("Start");
            Timestamp end = rs.getTimestamp("End");
            Timestamp createDate = rs.getTimestamp("Create_Date");
            String createBy = rs.getString("Created_By");
            Timestamp update = rs.getTimestamp("Last_Update");
            String updateBy = rs.getString("Last_Updated_By");
            Integer customerId = rs.getInt("Customer_ID");
            Integer userId = rs.getInt("User_ID");
            Integer contactID = rs.getInt("Contact_ID");
            Appointment appointment = new Appointment(appointmentId,title,description,location,type,start.toLocalDateTime(),end.toLocalDateTime(),createDate.toLocalDateTime(),createBy,update.toLocalDateTime(),updateBy,customerId,userId,contactID);
            AppointmentList.addAppointment(appointment);
        }
    }

    /**Clears the AllAppointments list.*/
    public static void clearAppointments(){
        AllAppointments.clear();
    }

    /**Creates the weekAppts list.*/
    private static ObservableList<Appointment> weekAppts = FXCollections.observableArrayList();

    /**Clears the weekAppts list.*/
    public static void clearWeekAppts() {weekAppts.clear();}

    /**Adds an appointment to the weekAppts list.*/
    public static void addWeekAppointment(Appointment appointment)
    {
        weekAppts.add(appointment);
    }

    /**Returns the weekAppts list.*/
    public static ObservableList<Appointment> getWeekAppts()
    {
        return weekAppts;
    }

    /**Uses SQL to populate the weekAppts list by selecting the list of appointments for the current week.*/
    public static void initializeWeekAppointmentList()  throws SQLException, IOException
    {
        //Connection conn = DBConnection.openConnection(); //Connect to database
        DBQuery.setStatement(DBConnection.getConnection());//create statement object
        Statement statement = DBQuery.getStatement();

        String selectAppointment = "SELECT * FROM appointments WHERE Start > '" + Timestamp.valueOf(Login.now) + "' AND Start < '" + Timestamp.valueOf(Login.now.plusDays(7)) + "';";
        statement.execute(selectAppointment);
        ResultSet rs = statement.getResultSet();


        while (rs.next())
        {
            Integer appointmentId = rs.getInt("Appointment_ID");
            String title = rs.getString("Title");
            String description = rs.getString("Description");
            String location = rs.getString("Location");
            String type = rs.getString("Type");
            Timestamp start = rs.getTimestamp("Start");
            Timestamp end = rs.getTimestamp("End");
            Timestamp createDate = rs.getTimestamp("Create_Date");
            String createBy = rs.getString("Created_By");
            Timestamp update = rs.getTimestamp("Last_Update");
            String updateBy = rs.getString("Last_Updated_By");
            Integer customerId = rs.getInt("Customer_ID");
            Integer userId = rs.getInt("User_ID");
            Integer contactID = rs.getInt("Contact_ID");
            Appointment appointment = new Appointment(appointmentId,title,description,location,type,start.toLocalDateTime(),end.toLocalDateTime(),createDate.toLocalDateTime(),createBy,update.toLocalDateTime(),updateBy,customerId,userId,contactID);
            AppointmentList.addWeekAppointment(appointment);
        }
    }

    /**Creates a list for appointments in the current month.*/
    private static ObservableList<Appointment> monthAppts = FXCollections.observableArrayList();

    /**Clears the weekAttps list.*/
    public static void clearMonthAppts() {weekAppts.clear();}

    /**adds an appointment to the monthAppts list.*/
    public static void addMonthAppointment(Appointment appointment)
    {
        monthAppts.add(appointment);
    }

    /**Returns the monthAppts list for appointments this month.*/
    public static ObservableList<Appointment> getMonthAppts()
    {
        return monthAppts;
    }

    /**Initializes the monthAppts list for appointments this month.*/
    public static void initializeMonthAppointmentList()  throws SQLException, IOException
    {
        //Connection conn = DBConnection.openConnection(); //Connect to database
        DBQuery.setStatement(DBConnection.getConnection());//create statement object
        Statement statement = DBQuery.getStatement();

        String selectAppointment = "SELECT * FROM appointments WHERE Start > '" + Timestamp.valueOf(Login.now) + "' AND Start < '" + Timestamp.valueOf(Login.now.plusMonths(1)) + "';";
        statement.execute(selectAppointment);
        ResultSet rs = statement.getResultSet();


        while (rs.next())
        {
            Integer appointmentId = rs.getInt("Appointment_ID");
            String title = rs.getString("Title");
            String description = rs.getString("Description");
            String location = rs.getString("Location");
            String type = rs.getString("Type");
            Timestamp start = rs.getTimestamp("Start");
            Timestamp end = rs.getTimestamp("End");
            Timestamp createDate = rs.getTimestamp("Create_Date");
            String createBy = rs.getString("Created_By");
            Timestamp update = rs.getTimestamp("Last_Update");
            String updateBy = rs.getString("Last_Updated_By");
            Integer customerId = rs.getInt("Customer_ID");
            Integer userId = rs.getInt("User_ID");
            Integer contactID = rs.getInt("Contact_ID");
            Appointment appointment = new Appointment(appointmentId,title,description,location,type,start.toLocalDateTime(),end.toLocalDateTime(),createDate.toLocalDateTime(),createBy,update.toLocalDateTime(),updateBy,customerId,userId,contactID);
            AppointmentList.addMonthAppointment(appointment);
        }
    }


}
