package Model;

import Utils.DBConnection;
import Utils.DBQuery;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;
/**Method for the Reports pages.*/
public class Reports {

    /**Creates the list for the TypeAppt to list appointments by type.*/
    private static ObservableList<Appointment> typeAppt = FXCollections.observableArrayList();

    /**Adds an appointment to the TypeAppt list.*/
    public static void addtypeAppt(Appointment appointment) {typeAppt.add(appointment);}

    /**Clears the TypeAppt list.*/
    public static void cleartypeAppt() {typeAppt.clear();}

    /**Counts the appointments by type and month.*/
    public static int countTypes (String type, int month) throws SQLException {
        int total = 0;
        DBQuery.setStatement(DBConnection.getConnection());
        Statement statement = DBQuery.getStatement();

        String count = ("SELECT count(Start) FROM client_schedule.appointments WHERE Type = \""  + type + "\" AND month(Start) = " +month + ";");
        statement.execute(count);
        ResultSet rs = statement.getResultSet();


        while (rs.next()){
            total = rs.getInt("count(Start)");
        }
        return total;
    }

    /**Counts all the appointments in the database.*/
    public static int countTotal () throws SQLException {
        int total = 0;
        DBQuery.setStatement(DBConnection.getConnection());
        Statement statement = DBQuery.getStatement();

        String count = ("SELECT count(Appointment_ID) FROM client_schedule.appointments;");
        statement.execute(count);
        ResultSet rs = statement.getResultSet();


        while (rs.next()){
            total = rs.getInt("count(Appointment_ID)");
        }
        return total;
    }

    /**Counts the customers appointments in the database.*/
    public static int countCust (int n) throws SQLException {
        int total = 0;
        DBQuery.setStatement(DBConnection.getConnection());
        Statement statement = DBQuery.getStatement();

        String count = ("SELECT count(Appointment_ID) FROM client_schedule.appointments WHERE Customer_ID = " + n + ";");
        statement.execute(count);
        ResultSet rs = statement.getResultSet();


        while (rs.next()){
            total = rs.getInt("count(Appointment_ID)");
        }
        return total;
    }

    /**Counts the appointments by customer and type.*/
    public static int countCustType (int n, String type) throws SQLException {
        int total = 0;
        DBQuery.setStatement(DBConnection.getConnection());
        Statement statement = DBQuery.getStatement();

        //SELECT count(Appointment_ID) FROM client_schedule.appointments WHERE Customer_ID = 2 AND Type = "Interview";
        String count = ("SELECT count(Appointment_ID) FROM client_schedule.appointments WHERE Customer_ID = " + n + " AND Type = \"" + type + "\";");
        statement.execute(count);
        ResultSet rs = statement.getResultSet();


        while (rs.next()){
            total = rs.getInt("count(Appointment_ID)");
        }
        return total;
    }
}
