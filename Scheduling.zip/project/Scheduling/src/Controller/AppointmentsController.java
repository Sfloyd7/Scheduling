package Controller;

import Model.Appointment;
import Model.AppointmentList;
import Model.Customer;
import Model.Login;
import Utils.DBConnection;
import com.mysql.cj.log.Log;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Optional;
import java.util.ResourceBundle;

public class AppointmentsController  implements Initializable {


    public TableView<Appointment> ApptTblvw;
    public TableColumn<Appointment, Integer> AppointmentIDCol;
    public TableColumn<Appointment, String> TitleCol;
    public TableColumn<Appointment, String> DescCol;
    public TableColumn<Appointment, String> LocationCol;
    public TableColumn<Appointment, Integer> ContactCol;
    public TableColumn<Appointment, String> TypeCol;
    public TableColumn<Appointment, String> StartCol;
    public TableColumn<Appointment, String> EndCol;
    public TableColumn<Appointment, Integer> CustIDCol;
    public TableColumn<Appointment, Integer> UserIdCol;



    Stage stage;
    Parent scene;

    @FXML
    private RadioButton AllAppointmentsRdBtn;

    @FXML
    private ToggleGroup TableSelectionGp;

    @FXML
    private RadioButton ThisWeekRdBtn;

    @FXML
    private RadioButton MonthRdBtn;


    /**Initialize method sets up the tableview.*/
    @Override
    public void initialize(URL location, ResourceBundle resources) {


        AppointmentList.clearAppointments();

        try {
            AppointmentList.initializeAppointmentList();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        ApptTblvw.setItems(AppointmentList.getAllAppointments());
        AppointmentIDCol.setCellValueFactory(new PropertyValueFactory<>("AppointmentId"));
        TitleCol.setCellValueFactory(new PropertyValueFactory<>("Title"));
        DescCol.setCellValueFactory(new PropertyValueFactory<>("Description"));
        LocationCol.setCellValueFactory(new PropertyValueFactory<>("Location"));
        ContactCol.setCellValueFactory(new PropertyValueFactory<>("ContactId"));
        TypeCol.setCellValueFactory(new PropertyValueFactory<>("Type"));
        StartCol.setCellValueFactory(new PropertyValueFactory<>("StartDisplay"));
        EndCol.setCellValueFactory(new PropertyValueFactory<>("EndDisplay"));
        CustIDCol.setCellValueFactory(new PropertyValueFactory<>("CustomerId"));
        UserIdCol.setCellValueFactory(new PropertyValueFactory<>("UserId"));

    }

    /**sets the tableview to show all appointments in the database.*/
    public void OnClickAllAppts(ActionEvent event) {

        AppointmentList.clearCustAppt();
        ApptTblvw.setItems(AppointmentList.getAllAppointments());
        AppointmentIDCol.setCellValueFactory(new PropertyValueFactory<>("AppointmentId"));
        TitleCol.setCellValueFactory(new PropertyValueFactory<>("Title"));
        DescCol.setCellValueFactory(new PropertyValueFactory<>("Description"));
        LocationCol.setCellValueFactory(new PropertyValueFactory<>("Location"));
        ContactCol.setCellValueFactory(new PropertyValueFactory<>("ContactId"));
        TypeCol.setCellValueFactory(new PropertyValueFactory<>("Type"));
        StartCol.setCellValueFactory(new PropertyValueFactory<>("StartDisplay"));
        EndCol.setCellValueFactory(new PropertyValueFactory<>("EndDisplay"));
        CustIDCol.setCellValueFactory(new PropertyValueFactory<>("CustomerId"));
        UserIdCol.setCellValueFactory(new PropertyValueFactory<>("UserId"));
    }

    /**Method populates the tableview to only show appointments for this week.*/
    public void OnClickWeek(ActionEvent event) {
        AppointmentList.clearWeekAppts();
        try {
            AppointmentList.initializeWeekAppointmentList();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        ApptTblvw.setItems(AppointmentList.getWeekAppts());
        AppointmentIDCol.setCellValueFactory(new PropertyValueFactory<>("AppointmentId"));
        TitleCol.setCellValueFactory(new PropertyValueFactory<>("Title"));
        DescCol.setCellValueFactory(new PropertyValueFactory<>("Description"));
        LocationCol.setCellValueFactory(new PropertyValueFactory<>("Location"));
        ContactCol.setCellValueFactory(new PropertyValueFactory<>("ContactId"));
        TypeCol.setCellValueFactory(new PropertyValueFactory<>("Type"));
        StartCol.setCellValueFactory(new PropertyValueFactory<>("StartDisplay"));
        EndCol.setCellValueFactory(new PropertyValueFactory<>("EndDisplay"));
        CustIDCol.setCellValueFactory(new PropertyValueFactory<>("CustomerId"));
        UserIdCol.setCellValueFactory(new PropertyValueFactory<>("UserId"));
    }

    /**Method populates the tableview to only show appointments in the next month.*/
    public void OnClickMonth(ActionEvent event) {
        AppointmentList.clearMonthAppts();
        try {
            AppointmentList.initializeMonthAppointmentList();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        ApptTblvw.setItems(AppointmentList.getMonthAppts());
        AppointmentIDCol.setCellValueFactory(new PropertyValueFactory<>("AppointmentId"));
        TitleCol.setCellValueFactory(new PropertyValueFactory<>("Title"));
        DescCol.setCellValueFactory(new PropertyValueFactory<>("Description"));
        LocationCol.setCellValueFactory(new PropertyValueFactory<>("Location"));
        ContactCol.setCellValueFactory(new PropertyValueFactory<>("ContactId"));
        TypeCol.setCellValueFactory(new PropertyValueFactory<>("Type"));
        StartCol.setCellValueFactory(new PropertyValueFactory<>("StartDisplay"));
        EndCol.setCellValueFactory(new PropertyValueFactory<>("EndDisplay"));
        CustIDCol.setCellValueFactory(new PropertyValueFactory<>("CustomerId"));
        UserIdCol.setCellValueFactory(new PropertyValueFactory<>("UserId"));
    }

    /**Method clears login information and returns to the login page.*/
    public void OnClickLogOff(ActionEvent actionEvent) throws IOException {
        Login.clearUsername();
        Login.clearNow();
        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/View/Login.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    public void OnClickAdd(ActionEvent actionEvent) throws IOException {
        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/AppointmentDetails.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**takes the selected appointment from the tableview and opens the update appointment page.
     * this method also sends the selected appointment and populates the appointment update page.*/
    public void OnClickUpdate(ActionEvent actionEvent) throws IOException, SQLException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/view/AppointmentUpdate.fxml"));
        loader.load();

        AppointmentUpdateController ApptUpdateController = loader.getController();
        ApptUpdateController.sendAppointment(ApptTblvw.getSelectionModel().getSelectedItem());

        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        Parent scene = loader.getRoot();
        stage.setScene(new Scene(scene));
        stage.show();
    }

    public void OnclickDelete(ActionEvent event) throws SQLException, IOException {
        Appointment appointment = ApptTblvw.getSelectionModel().getSelectedItem();
        int appointmentId = appointment.getAppointmentId();
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION,"You are about to cancel Appointment ID: " + appointmentId + " Type: " + appointment.getType());
        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            AppointmentList.deleteAppointment(appointmentId);
        }
        AppointmentList.clearAppointments();

        try {
            AppointmentList.initializeAppointmentList();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        ApptTblvw.setItems(AppointmentList.getAllAppointments());
        AppointmentIDCol.setCellValueFactory(new PropertyValueFactory<>("AppointmentId"));
        TitleCol.setCellValueFactory(new PropertyValueFactory<>("Title"));
        DescCol.setCellValueFactory(new PropertyValueFactory<>("Description"));
        LocationCol.setCellValueFactory(new PropertyValueFactory<>("Location"));
        ContactCol.setCellValueFactory(new PropertyValueFactory<>("ContactId"));
        TypeCol.setCellValueFactory(new PropertyValueFactory<>("Type"));
        StartCol.setCellValueFactory(new PropertyValueFactory<>("StartDisplay"));
        EndCol.setCellValueFactory(new PropertyValueFactory<>("EndDisplay"));
        CustIDCol.setCellValueFactory(new PropertyValueFactory<>("CustomerId"));
        UserIdCol.setCellValueFactory(new PropertyValueFactory<>("UserId"));

    }

    public void OnClickCustomers(ActionEvent actionEvent) throws IOException {
        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/CustomerRecords.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    public void OnClickReports(ActionEvent actionEvent) throws IOException {
        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/Reports.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }


}
