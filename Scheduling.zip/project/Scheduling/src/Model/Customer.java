package Model;

import java.sql.Date;
import java.sql.Timestamp;
import java.time.LocalDateTime;
/**Method for the Customer getters and setters.*/
public class Customer {

    private Integer CustomerId;
    private String CustomerName;
    private String Address;
    private String PostalCode;
    private String Phone;
    private LocalDateTime CreateDate;
    private String CreateBy;
    private LocalDateTime LastUpdate;
    private String UpdateBy;
    private Integer DivisionId;

    /**Constructor for the Customer.*/
    public Customer(Integer customerId, String customerName, String address, String postalCode, String phone, LocalDateTime createDate, String createBy, LocalDateTime lastUpdate, String updateBy, Integer divisionId) {
        CustomerId = customerId;
        CustomerName = customerName;
        Address = address;
        PostalCode = postalCode;
        Phone = phone;
        CreateDate = createDate;
        CreateBy = createBy;
        LastUpdate = lastUpdate;
        UpdateBy = updateBy;
        DivisionId = divisionId;
    }

    /**@return Returns Customer ID.*/
    public Integer getCustomerId() {
        return CustomerId;
    }

    /**@param customerId Sets the customer ID for a given Customer.*/
    public void setCustomerId(int customerId) {
        CustomerId = customerId;
    }

    /**@return Returns the Customer Name.*/
    public String getCustomerName() {
        return CustomerName;
    }

    /**@param customerName Sets the customer name for a Customer.*/
    public void setCustomerName(String customerName) {
        CustomerName = customerName;
    }

    /**@return Returns the address for a customer.*/
    public String getAddress() {
        return Address;
    }

    /**@param address Sets the address for a customer.*/
    public void setAddress(String address) {
        Address = address;
    }

    /**@return returns the postal code for a customer.*/
    public String getPostalCode() {
        return PostalCode;
    }

    /**@param postalCode Sets the postal code for a customer.*/
    public void setPostalCode(String postalCode) {
        PostalCode = postalCode;
    }

    /**@return Returns a customers phone number.*/
    public String getPhone() {
        return Phone;
    }

    /**@param phone Sets the phone number for a given Customer.*/
    public void setPhone(String phone) {
        Phone = phone;
    }

    /**@return Returns the date and time the customer was created.*/
    public LocalDateTime getCreateDate() {
        return CreateDate;
    }

    /**@param createDate Sets the date and time the Customer was created.*/
    public void setCreateDate(LocalDateTime createDate) {
        CreateDate = createDate;
    }

    /**@return Returns who created the customer. */
    public String getCreateBy() {
        return CreateBy;
    }

    /**@param createBy Sets who created the Customer.*/
    public void setCreateBy(String createBy) {
        CreateBy = createBy;
    }

    /**@return Returns the date and time the customer was last updated.*/
    public LocalDateTime getLastUpdate() {
        return LastUpdate;
    }

    /**@param lastUpdate Sets when the customer was last updated.*/
    public void setLastUpdate(LocalDateTime lastUpdate) {
        LastUpdate = lastUpdate;
    }

    /**@return Returns who last updated the customer information.*/
    public String getUpdateBy() {
        return UpdateBy;
    }

    /**@param updateBy Sets who last updated the Customer information.*/
    public void setUpdateBy(String updateBy) {
        UpdateBy = updateBy;
    }

    /**@return Returns the State or division where the customer is located.*/
    public int getDivisionId() {
        return DivisionId;
    }

    /**@param divisionId Sets the state or division where the Customer is located.*/
    public void setDivisionId(Integer divisionId) {
        DivisionId = divisionId;
    }

    /**Overrides the to string so you can see the Customer name in drop downs.*/
    @Override
    public String toString(){
        return (CustomerName);
    }
}
