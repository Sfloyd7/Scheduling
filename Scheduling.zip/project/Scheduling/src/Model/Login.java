package Model;

import Utils.DBConnection;
import Utils.DBQuery;
import com.mysql.cj.log.Log;

import java.sql.*;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

import static java.time.ZoneOffset.UTC;
/**Method for the Login information.*/
public class Login {

    /**Saves the username for who is siged in.*/
    private static String username;

    /**@return Returns the username.*/
    public static String getUsername() {
        return username;
    }

    /**@param username Sets the username for who is signed in.*/
    public static void setUsername(String username) {
        Login.username = username;
    }

    /**Clears the username for next login.*/
    public static void clearUsername(){username = null;}

    /**Saves the current timestamp.*/
    public static LocalDateTime now;

    /**@return Returns the current timestamp of login.*/
    public static LocalDateTime getNow() {return now;}

    /**@param localDateTime Sets the current date and time.*/
    public static void setNow(LocalDateTime localDateTime) {now = localDateTime;}

    /**Clears the current date and time for next login.*/
    public static void clearNow(){now = null;}

    /**Uses SQL to find if there is an appointment withint 15 minutes of login.*/
    public static Appointment getAppointment() throws SQLException {
        Appointment appointment = null;

        LocalDateTime now = LocalDateTime.now();
        ZonedDateTime znow = now.atZone(ZoneId.systemDefault());
        ZonedDateTime urcNow = znow.withZoneSameInstant(ZoneId.of("UTC"));
        LocalDateTime nowPlus15 = now.plusMinutes(15);
        ZonedDateTime znowPlus15 = nowPlus15.atZone(ZoneId.systemDefault());
        ZonedDateTime urcNowPlus15 = znowPlus15.withZoneSameInstant(ZoneId.of("UTC"));
        LocalDateTime utcNow = urcNow.toLocalDateTime();
        Timestamp timestamp = Timestamp.valueOf(utcNow);
        LocalDateTime utcNowplus15 = urcNowPlus15.toLocalDateTime();
        Timestamp time = Timestamp.valueOf(utcNowplus15);
        //ZonedDateTime nowAtUTC = now(UTC);
        //LocalDateTime converted = nowAtUTC.toLocalDateTime();
        DateTimeFormatter converted = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:MM:SS");
        String string = urcNow.format(converted);
        String stringplus15 = urcNowPlus15.format(converted);
        //Timestamp timestamp = Timestamp.valueOf(nowAtUTC);
        //Timestamp time = Timestamp.valueOf(nowAtUTC.plusMinutes(15));
        System.out.println("Now: " + string);
        System.out.println("15 After: "+ stringplus15);
        DBQuery.setStatement(DBConnection.getConnection());//create statement object
        Statement statement = DBQuery.getStatement();

        String selectAppointment = "SELECT * FROM appointments WHERE Start > '" + timestamp + "' AND Start < '" + time + "';";
        statement.execute(selectAppointment);
        ResultSet rs = statement.getResultSet();


        while (rs.next())
        {
            Integer appointmentId = rs.getInt("Appointment_ID");
            String title = rs.getString("Title");
            String description = rs.getString("Description");
            String location = rs.getString("Location");
            String type = rs.getString("Type");
            Timestamp start = rs.getTimestamp("Start");
            Timestamp end = rs.getTimestamp("End");
            Timestamp createDate = rs.getTimestamp("Create_Date");
            String createBy = rs.getString("Created_By");
            Timestamp update = rs.getTimestamp("Last_Update");
            String updateBy = rs.getString("Last_Updated_By");
            Integer customerId = rs.getInt("Customer_ID");
            Integer userId = rs.getInt("User_ID");
            Integer contactID = rs.getInt("Contact_ID");
            appointment = new Appointment(appointmentId,title,description,location,type,start.toLocalDateTime(),end.toLocalDateTime(),createDate.toLocalDateTime(),createBy,update.toLocalDateTime(),updateBy,customerId,userId,contactID);
        }

        return appointment;
    }


}
