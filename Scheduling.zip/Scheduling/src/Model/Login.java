package Model;

public class Login {

    private static String username;

    public static String getUsername() {
        return username;
    }

    public static void setUsername(String username) {
        Login.username = username;
    }
}
