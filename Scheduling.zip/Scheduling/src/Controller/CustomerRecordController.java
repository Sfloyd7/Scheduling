package Controller;

import Model.Customer;
import Model.CustomerList;
import Utils.DBConnection;
import Utils.DBQuery;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import Utils.PageChange;
import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

public class CustomerRecordController  implements Initializable {
    
    public TableView<Customer> CustomerTable;
    public TableColumn<Customer, Integer> IDCol;
    public TableColumn<Customer, String> NameCol;
    public TableColumn<Customer, String> AddressCol;
    public TableColumn<Customer, String> ZipCol;
    public TableColumn<Customer, String> PhoneCol;


    Stage stage;
    Parent scene;



    @Override
    public void initialize(URL url, ResourceBundle resourceBundle)
    {

        CustomerList.clearCustomers();

        try {
            CustomerList.initializeCustomerList();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        CustomerTable.setItems(CustomerList.getAllCustomers());
        IDCol.setCellValueFactory(new PropertyValueFactory<>("CustomerId"));
        NameCol.setCellValueFactory(new PropertyValueFactory<>("CustomerName"));
        AddressCol.setCellValueFactory(new PropertyValueFactory<>("Address"));
        ZipCol.setCellValueFactory(new PropertyValueFactory<>("PostalCode"));
        PhoneCol.setCellValueFactory(new PropertyValueFactory<>("Phone"));

        
    }

    public void OnClickAdd(ActionEvent actionEvent) throws IOException {
        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/View/CustomerDetails.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    public void OnClickUpdate(ActionEvent actionEvent) throws IOException {
        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/View/CustomerUpdate.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    public void OnClickDelete(ActionEvent event) {
    }

    public void OnClickAppointments(ActionEvent actionEvent) throws IOException {
        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(PageChange.class.getResource("/view/Appointments.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }


    public void OnclickReports(ActionEvent event) {
    }

    public void OnClickLogoff(ActionEvent actionEvent) throws IOException {
        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/View/Login.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }


}
