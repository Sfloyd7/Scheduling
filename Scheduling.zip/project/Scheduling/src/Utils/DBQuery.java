package Utils;

import javax.swing.plaf.nimbus.State;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
/**This Method determins the ability to query the database. There are two types. The Prepared statment and the statement.*/
public class DBQuery {
    
    private static Statement statement;
    private static PreparedStatement preparedStatement;
    
    /**This creates the statement object.*/
    public static void setStatement(Connection conn)throws SQLException
    {
        statement = conn.createStatement();
    }

    /**This returns the Statement Object.*/
    public static Statement getStatement()
    {
        return statement;
    }

    /**This creates the Prepared Statement object.*/
    public static void setPreparedStatement(Connection conn, String sqlStatement) throws SQLException
    {
        statement= conn.prepareStatement(sqlStatement);
    }
    /**This returns the Prepared Statement Object.*/
    public static PreparedStatement getPreparedStatement(){return preparedStatement;}



}
