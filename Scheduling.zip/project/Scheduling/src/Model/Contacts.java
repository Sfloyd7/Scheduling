package Model;
/**The Method for the Contacts setters and getters. */
public class Contacts {

    private int Contact_ID;
    private String ContactName;
    private String Email;

    /**Constructor for the Contacts.*/
    public Contacts(int contact_id, String contactName, String email) {
        Contact_ID = contact_id;
        ContactName = contactName;
        Email = email;
    }

    /**@return Returns the ContactID.*/
    public int getContact_ID() {
        return Contact_ID;
    }

    /**@param contact_ID Sets the contactID for the Contact.*/
    public void setContact_ID(int contact_ID) {
        Contact_ID = contact_ID;
    }

    /**@return Returns the Contact Name for the contact.*/
    public String getContactName() {
        return ContactName;
    }

    /**@param contactName Sets the contactName for the contact.*/
    public void setContactName(String contactName) {
        ContactName = contactName;
    }

    /**@return Returns the Email for a given contact.*/
    public String getEmail() {
        return Email;
    }

    /**@param email Sets the email for a given contact.*/
    public void setEmail(String email) {
        Email = email;
    }

    /**overrides the contact name as the drop downs in the appointments page.*/
    @Override
    public String toString(){
        return (ContactName);
    }



}
