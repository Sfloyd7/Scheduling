package Controller;

import Model.Login;
import Model.Reports;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

/**Controller for the type reports page.*/
public class TypeController implements Initializable {


    @FXML
    private ComboBox<String> TypeCmb;

    @FXML
    private Label JanuaryLbl;

    @FXML
    private Label FebruaryLbl;

    @FXML
    private Label MarchLbl;

    @FXML
    private Label AprilLbl;

    @FXML
    private Label MayLbl;

    @FXML
    private Label JuneLbl;

    @FXML
    private Label FebruarLbl1;

    @FXML
    private Label JulyLbl;

    @FXML
    private Label AugustLbl;

    @FXML
    private Label SeptemberLbl;

    @FXML
    private Label OctoberLbl;

    @FXML
    private Label NovemberLbl;

    @FXML
    private Label DecemberLbl;

    @FXML
    Stage stage;
    Parent scene;
    /**Button that navigates to the appointments page.*/
    @FXML
    void OnClickAppointments(ActionEvent actionEvent) throws IOException {
        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/View/Appointments.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();

    }

    /**Button that navigates to the Login page and clears the login model information.*/
    @FXML
    void OnClickLogOff(ActionEvent actionEvent) throws IOException {
        Login.clearUsername();
        Login.clearNow();
        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/View/Login.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();

    }


    /**Button takes you to the customer records page.*/
    @FXML
    void onClickCustomers(ActionEvent actionEvent) throws IOException {
        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/CustomerRecords.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();


    }

    /**Button takes you to the schedule report page.*/
    @FXML
    void onClickSchedule(ActionEvent actionEvent) throws IOException {
        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/reports.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();

    }

    /**Drop down box gets the type selected and populates the labels with the counts.*/
    @FXML
    void onClickSelect(ActionEvent event) {
        try {
            JanuaryLbl.setText(String.valueOf(Reports.countTypes(TypeCmb.getValue(),1)));
            FebruaryLbl.setText(String.valueOf(Reports.countTypes(TypeCmb.getValue(),2)));
            MarchLbl.setText(String.valueOf(Reports.countTypes(TypeCmb.getValue(),3)));
            AprilLbl.setText(String.valueOf(Reports.countTypes(TypeCmb.getValue(),4)));
            MayLbl.setText(String.valueOf(Reports.countTypes(TypeCmb.getValue(),5)));
            JuneLbl.setText(String.valueOf(Reports.countTypes(TypeCmb.getValue(),6)));
            JulyLbl.setText(String.valueOf(Reports.countTypes(TypeCmb.getValue(),7)));
            AugustLbl.setText(String.valueOf(Reports.countTypes(TypeCmb.getValue(),8)));
            SeptemberLbl.setText(String.valueOf(Reports.countTypes(TypeCmb.getValue(),9)));
            OctoberLbl.setText(String.valueOf(Reports.countTypes(TypeCmb.getValue(),10)));
            NovemberLbl.setText(String.valueOf(Reports.countTypes(TypeCmb.getValue(),11)));
            DecemberLbl.setText(String.valueOf(Reports.countTypes(TypeCmb.getValue(),12)));
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

    }

    /**Button to navigate to the overview reports page.*/
    @FXML
    void onClickSomething(ActionEvent actionEvent) throws IOException {
        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/Overview.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();

    }


    /**Populates the Type drop down and selects the first opetion.
     * this populates the labels for the type counts.*/
    @Override
    public void initialize(URL location, ResourceBundle resources) {

        ObservableList<String> types = FXCollections.observableArrayList("Interview", "Planning Session", "Job Summary", "De-Briefing");
        TypeCmb.setItems(types);
        TypeCmb.setValue(types.get(0));

        try {
            JanuaryLbl.setText(String.valueOf(Reports.countTypes(TypeCmb.getValue(),1)));
            FebruaryLbl.setText(String.valueOf(Reports.countTypes(TypeCmb.getValue(),2)));
            MarchLbl.setText(String.valueOf(Reports.countTypes(TypeCmb.getValue(),3)));
            AprilLbl.setText(String.valueOf(Reports.countTypes(TypeCmb.getValue(),4)));
            MayLbl.setText(String.valueOf(Reports.countTypes(TypeCmb.getValue(),5)));
            JuneLbl.setText(String.valueOf(Reports.countTypes(TypeCmb.getValue(),6)));
            JulyLbl.setText(String.valueOf(Reports.countTypes(TypeCmb.getValue(),7)));
            AugustLbl.setText(String.valueOf(Reports.countTypes(TypeCmb.getValue(),8)));
            SeptemberLbl.setText(String.valueOf(Reports.countTypes(TypeCmb.getValue(),9)));
            OctoberLbl.setText(String.valueOf(Reports.countTypes(TypeCmb.getValue(),10)));
            NovemberLbl.setText(String.valueOf(Reports.countTypes(TypeCmb.getValue(),11)));
            DecemberLbl.setText(String.valueOf(Reports.countTypes(TypeCmb.getValue(),12)));
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }


    }
}
