package Controller;

import Model.*;
import Utils.DBConnection;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.io.*;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.sql.*;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Locale;
import java.util.Optional;
import java.util.ResourceBundle;
/**Controller for the login page.*/
public class LoginController implements Initializable {

    public Label UsernameLbl;
    public Label PasswordLbl;
    public Button exitBtn;
    public Button logonBtn;
    Stage stage;
    Parent scene;




    @FXML public TextField UserNameTxt;
    @FXML public TextField PasswordTxt;
    @FXML public Label LocationLbl;
    @FXML public Label ErrorLbl;

    /**Initialize sets up the Location label with the default zone ID of the user.*/
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        LocationLbl.setText(String.valueOf(ZoneId.systemDefault()));
        System.out.println(Instant.now());

        try {
            ResourceBundle rb = ResourceBundle.getBundle("Utils/Nat", Locale.getDefault());
            if (Locale.getDefault().getLanguage().equals("fr")|| Locale.getDefault().getLanguage().equals("en")) {
                UsernameLbl.setText(rb.getString("username"));
                PasswordLbl.setText(rb.getString("password"));
                logonBtn.setText(rb.getString("login"));
                exitBtn.setText(rb.getString("exit"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**Login button verifies the username and password is right.
     * Sets the username in the login model. This also does the resources to translate the error messages.*/
    public void OnClickLogon(ActionEvent actionEvent) throws SQLException, IOException {


        String UserName = UserNameTxt.getText();
        String Password = PasswordTxt.getText();
        boolean login = false;


                String selectStatement = "SELECT * from client_schedule.users";
        //Connection conn = DBConnection.getConnection(); //Connect to database
        /*DBQuery.setPreparedStatement(DBConnection.getConnection(),selectStatement);//create statement object

        Statement statement = DBQuery.getPreparedStatement();*/
        try {
            PreparedStatement ps = DBConnection.getConnection().prepareStatement(selectStatement);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String username = rs.getString("User_Name");
                String password = rs.getString("Password");
                if ((UserName.equals(username)) && (Password.equals(password))) {
                    Login.setUsername(username);
                    Login.setNow(LocalDateTime.now());
                    System.out.println(username);
                    login = true;



                    stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
                    scene = FXMLLoader.load(getClass().getResource("/View/Appointments.fxml"));
                    stage.setScene(new Scene(scene));
                    stage.show();


                    Appointment appointment = Login.getAppointment();


                    /**My first Lambda expression passing 2 strings to create the alert message.*/
                    if (appointment != null) {
                        AlertMessageInterface message = (s1, s2) -> "There is an appointment soon. Appointment ID: " + s1 + " is at " + s2;
                        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, message.getMessage(String.valueOf(appointment.getAppointmentId()), appointment.getStartDisplay()));
                        Optional<ButtonType> result = alert.showAndWait();
                    } else {
                        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "You have no upcoming appointments");
                        Optional<ButtonType> result = alert.showAndWait();

                    }
                } else

                try {
                    ResourceBundle rb = ResourceBundle.getBundle("Utils/Nat", Locale.getDefault());
                    if (Locale.getDefault().getLanguage().equals("fr") || Locale.getDefault().getLanguage().equals("en"))
                        ErrorLbl.setText(rb.getString("username") + " " + rb.getString("or") + " " + rb.getString("password") + " " + rb.getString("is") + " " + rb.getString("incorrect"));


                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
            /**This area adds the login information to the login_activity.txt page.*/
            if (login){
                //file name variable
                String filename = "src/login_activity.txt";
                //Create and Open file
                FileWriter fileWriter = new FileWriter(filename, true);
                PrintWriter outputfile = new PrintWriter(fileWriter);
                outputfile.println(UserName + ", " + ZonedDateTime.now(ZoneId.of("UTC")) + ", Successful");
                outputfile.close();
            }
            else if (!login){
                //file name variable
                String filename = "src/login_activity.txt";
                //Create and Open file
                FileWriter fileWriter = new FileWriter(filename, true);
                PrintWriter outputfile = new PrintWriter(fileWriter);
                outputfile.println(UserName + ", " + ZonedDateTime.now(ZoneId.of("UTC")) + ", Unsuccessful");
                outputfile.close();
            }


        }
        catch (SQLException e){
            e.printStackTrace();
        }


        //statement.execute(selectStatement);
        //ResultSet rs = statement.getResultSet();




    }
    /**Button to exit the program.*/
    public void OnClickExit(ActionEvent event) {
        System.exit(0);
        DBConnection.closeConnection();


    }



}
