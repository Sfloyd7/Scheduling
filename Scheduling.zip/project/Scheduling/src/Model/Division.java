package Model;

import java.sql.Timestamp;
/**Method that creats the division with getters and setters.*/
public class Division {

    private int divisionId;
    private String division;
    private Timestamp createDate;
    private String createdBy;
    private Timestamp lastUpdated;
    private String lastUpdatedBy;
    private int countryId;

    /**Constructor for the Division.*/
    public Division(int divisionId, String division, Timestamp createDate, String createdBy, Timestamp lastUpdated, String lastUpdatedBy, int countryId) {
        this.divisionId = divisionId;
        this.division = division;
        this.createDate = createDate;
        this.createdBy = createdBy;
        this.lastUpdated = lastUpdated;
        this.lastUpdatedBy = lastUpdatedBy;
        this.countryId = countryId;
    }

    /**@return Returns a divisions DivisionId.*/
    public int getDivisionId() {
        return divisionId;
    }

    /**@param divisionId Sets a divisions division ID.*/
    public void setDivisionId(int divisionId) {
        this.divisionId = divisionId;
    }

    /**@return Returns a division's Division Name.*/
    public String getDivision() {
        return division;
    }

    /**@param division Sets a divisions name.*/
    public void setDivision(String division) {
        this.division = division;
    }

    /**@return Returns the date the division was added to the database.*/
    public Timestamp getCreateDate() {
        return createDate;
    }

    /**@param createDate Sets the date the Division was added to the database.*/
    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    /**@return Returns who added the division to the database.*/
    public String getCreatedBy() {
        return createdBy;
    }

    /**@param createdBy Sets who added the division to the database.*/
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    /**@return Returns the timestamp for when the division was last updated.*/
    public Timestamp getLastUpdated() {
        return lastUpdated;
    }

    /**@param lastUpdated sets the timestamp the division was last updated.*/
    public void setLastUpdated(Timestamp lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    /**@return Returns who last updated the division.*/
    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    /**@param lastUpdatedBy Sets who last updated the Division.*/
    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    /**@return Returns the Country ID where the division is located.*/
    public int getCountryId() {
        return countryId;
    }

    /**@param countryId Sets the country ID where the division is located.*/
    public void setCountryId(int countryId) {
        this.countryId = countryId;
    }

    /**Overrides the to string to show the division name on the drop downs.*/
    @Override
    public String toString(){
        return (division);
    }
}
