package Controller;

import Model.Customer;
import Model.CustomerList;
import Model.Login;
import Model.Reports;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

/**Overview reports page controller.*/
public class OverviewController implements Initializable {

    Stage stage;
    Parent scene;

    @FXML
    private ComboBox<Customer> CustomerCmb;

    @FXML
    private Label TtlApptLbl;

    @FXML
    private Label CustApptLbl;

    @FXML
    private Label InterviewLbl;

    @FXML
    private Label PlanningLbl;

    @FXML
    private Label SummaryLbl;

    @FXML
    private Label DeBriefingLbl;

    /**Button that takes you to the appointments screen.*/
    @FXML
    void OnClickAppointments(ActionEvent actionEvent) throws IOException {
        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/Appointments.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();

    }

    /**Button that takes you to the login page and clears the login model data.*/
    @FXML
    void OnClickLogOff(ActionEvent actionEvent) throws IOException {
        Login.clearUsername();
        Login.clearNow();
        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/View/Login.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();

    }

    /**Button that takes you to the customer records page.*/
    @FXML
    void onClickCustomers(ActionEvent actionEvent) throws IOException {
        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/CustomerRecords.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();

    }

    /**Button that takes you to the Schedule page.*/
    @FXML
    void onClickSchedule(ActionEvent actionEvent) throws IOException {
        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/Reports.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();

    }

    /**Gets the customer selected and populates the lables with the number of appointments of the different types.*/
    @FXML
    void onClickSelect(ActionEvent event) {
        Customer c = CustomerCmb.getValue();
        if(c!=null) {
            int CustId = CustomerCmb.getValue().getCustomerId();
            try {
                TtlApptLbl.setText(String.valueOf(Reports.countTotal()));
                CustApptLbl.setText(String.valueOf((Reports.countCust(CustId))));
                InterviewLbl.setText(String.valueOf(Reports.countCustType(CustId, "Interview")));
                PlanningLbl.setText(String.valueOf(Reports.countCustType(CustId, "Planning Session")));
                DeBriefingLbl.setText(String.valueOf(Reports.countCustType(CustId, "De-Briefing")));
                SummaryLbl.setText(String.valueOf(Reports.countCustType(CustId, "Job Summary")));
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }

    }

    /**Button that takes you to the type reports screen.*/
    @FXML
    void onClickType(ActionEvent actionEvent) throws IOException {
        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/TypeReport.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();


    }

    /**Initialize method that populates the Customer list drop down.*/
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        CustomerList.clearCustomers();

        try {
            CustomerList.initializeCustomerList();

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        CustomerCmb.setItems(CustomerList.getAllCustomers());
        CustomerCmb.setValue(CustomerList.getAllCustomers().get(0));

        try {
            int CustId = CustomerCmb.getValue().getCustomerId();
            TtlApptLbl.setText(String.valueOf(Reports.countTotal()));
            CustApptLbl.setText(String.valueOf((Reports.countCust(CustId))));
            InterviewLbl.setText(String.valueOf(Reports.countCustType(CustId,"Interview")));
            PlanningLbl.setText(String.valueOf(Reports.countCustType(CustId,"Planning Session")));
            DeBriefingLbl.setText(String.valueOf(Reports.countCustType(CustId,"De-Briefing")));
            SummaryLbl.setText(String.valueOf(Reports.countCustType(CustId,"Job Summary")));
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
}
