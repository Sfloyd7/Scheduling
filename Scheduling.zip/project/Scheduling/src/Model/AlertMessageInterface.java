package Model;
/**Lambda interface for a dual message abstract.*/
public interface AlertMessageInterface {

    //void abstract message
    //void displayMessage(String s);
    //multiple parameter abstract method.
    //int calculateSum(int n1, int n2);
    //No Parameter Abstract Method
    String getMessage(String s1,String s2);

}
