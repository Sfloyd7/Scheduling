package Model;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.chrono.ChronoZonedDateTime;
import java.time.format.DateTimeFormatter;

import static java.time.ZoneId.systemDefault;
import static java.time.ZoneOffset.UTC;

public class Appointment {

    private int AppointmentId;
    private String Title;
    private String Description;
    private String Location;
    private String Type;
    private LocalDateTime Start;
    private LocalDateTime End;
    private LocalDateTime CreateDate;
    private String CreatedBy;
    private LocalDateTime LastUpdate;
    private String UpdatedBy;
    private int CustomerId;
    private int UserId;
    private int ContactId;
    private String StartDisplay;
    private String EndDisplay;

/**Appointment Constructor. */
    public Appointment(int appointmentId, String title, String description, String location, String type, LocalDateTime start, LocalDateTime end, LocalDateTime createDate, String createdBy, LocalDateTime lastUpdate, String updatedBy, int customerId, int userId, int contactId) {
        AppointmentId = appointmentId;
        Title = title;
        Description = description;
        Location = location;
        Type = type;
        Start = start;
        End = end;
        CreateDate = createDate;
        CreatedBy = createdBy;
        LastUpdate = lastUpdate;
        UpdatedBy = updatedBy;
        CustomerId = customerId;
        UserId = userId;
        ContactId = contactId;
    }

    /**@return Returns appointment ID.*/
    public int getAppointmentId() {
        return AppointmentId;
    }

    /**@param appointmentId sets the appointmentId.*/
    public void setAppointmentId(int appointmentId) {
        AppointmentId = appointmentId;
    }

    /**@return Returns the title.*/
    public String getTitle() {
        return Title;
    }

    /**@param title Sets the titls.*/
    public void setTitle(String title) {
        Title = title;
    }

    /**@return Returns Description of this appointment.*/
    public String getDescription() {
        return Description;
    }

    /**@param description Sets the description for the appointment.*/
    public void setDescription(String description) {
        Description = description;
    }

    /**@return returns the location of the Appointment.*/
    public String getLocation() {
        return Location;
    }

    /**@param location Sets the Location for the appointment.*/
    public void setLocation(String location) {
        Location = location;
    }

    /**@return Returns the type of appointment.*/
    public String getType() {
        return Type;
    }

    /**@param type Sets the Appointment Type.*/
    public void setType(String type) {
        Type = type;
    }

    /**@return Returns the start date and time of the Appointment.*/
    public LocalDateTime getStart() { return Start;
    }

    /**@param start Sets the start date and time of the Appointment.*/
    public void setStart(LocalDateTime start) {
        Start = start;
    }

    /**@return Returns the end date and time of the appointment.*/
    public LocalDateTime getEnd() {
        return End;
    }

    /**@param end Sets the start date and time of the Appointment.*/
    public void setEnd(LocalDateTime end) {
        End = end;
    }

    /**@return Returns the date and time the Appointment was created.*/
    public LocalDateTime getCreateDate() {
        return CreateDate;
    }

    /**@param createDate Sets the date and time the Appointment was created.*/
    public void setCreateDate(LocalDateTime createDate) {
        CreateDate = createDate;
    }

    /**@return Returns who created the appointment.*/
    public String getCreatedBy() {
        return CreatedBy;
    }

    /**@param createdBy Sets who created the Appointment.*/
    public void setCreatedBy(String createdBy) {
        CreatedBy = createdBy;
    }

    /**@return Returns the date and time the appointment was last updated.*/
    public LocalDateTime getLastUpdate() {
        return LastUpdate;
    }

    /**@param lastUpdate Sets the date and time the Appointment was last updated.*/
    public void setLastUpdate(LocalDateTime lastUpdate) {
        LastUpdate = lastUpdate;
    }

    /**@return Returns who last updated the appointment.*/
    public String getUpdatedBy() {
        return UpdatedBy;
    }

    /**@param updatedBy Sets who last updated the Appointment.*/
    public void setUpdatedBy(String updatedBy) {
        UpdatedBy = updatedBy;
    }

    /**@return Returns the Customer ID who is attending the appointment.*/
    public int getCustomerId() {
        return CustomerId;
    }

    /**@param customerId Sets the Customer Attending the Appointment.*/
    public void setCustomerId(int customerId) {
        CustomerId = customerId;
    }

    /**@return Returns the UserId for the Appointment.*/
    public int getUserId() {
        return UserId;
    }

    /**@param userId Sets the user ID for the Appointment.*/
    public void setUserId(int userId) {
        UserId = userId;
    }

    /**@return Returns the ContactID for the Appointment.*/
    public int getContactId() {
        return ContactId;
    }

    /**@param contactId Sets the contactId for the Appointment.*/
    public void setContactId(int contactId) {
        ContactId = contactId;
    }

    /**@return Returns the start date and time for viewing.*/
    public String getStartDisplay(){
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        StartDisplay= Start.format(formatter);
        return StartDisplay;

    }

    /**@param startDisplay Sets the start format for viewing.*/
    public void setStartDisplay(String startDisplay){StartDisplay = startDisplay;}

    /**@return Returns the start date and time for viewing.*/
    public String getEndDisplay(){
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
       EndDisplay= End.format(formatter);
        return EndDisplay;
    }

    /**@param endDisplay Sets the end date and time in a format for viewing.*/
    public void setEndDisplay(String endDisplay){EndDisplay = endDisplay;}

}
