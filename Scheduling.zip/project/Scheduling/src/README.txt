Scheduling

This program was designed to help maintain this companies Customer and
appointment databases.

Author: Sarah Floyd
Contact: sfloy37@wgu.edu
Application Version:1
Date: 10/20/2021
IDE Version:IntelliJ IDEA Community Edistion 2021.1.1
JDK Version: JDK 11 version 11.0.11
JavaFX Version: javafx-sdk-11.0.2
MySQL Connector Driver Version: mysql-connector-java-8.0.25

Directions:

Enter username and password on the login page.
The program will take you to the appointment summary page.
You may add update or cancel appointments from here.
Click the customer pager to go to the customer summary page.
You may add update and delete customers from here.
If you go to the reports page you will get several summary views.

Additional Report:

My additional report was a list if count statements.
Total Appointments in the database.
You select the customer and it breaks down the total appointments for the customer.
It breaks that down into the types of appointments for that customer.